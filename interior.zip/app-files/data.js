var APP_DATA = {
  "scenes": [
    {
      "id": "0-20210301_234416_900",
      "name": "20210301_234416_900",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": -2.6837079336004344,
        "pitch": 0.05759254282144788,
        "fov": 1.4185322104917357
      },
      "linkHotspots": [
        {
          "yaw": -2.745978533476272,
          "pitch": 0.07742535691527763,
          "rotation": 0,
          "target": "1-20210301_234419_512"
        },
        {
          "yaw": 0.5502591995086501,
          "pitch": 0.12078794281523564,
          "rotation": 0,
          "target": "2-20210301_234421_150"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-20210301_234419_512",
      "name": "20210301_234419_512",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 2.355416785922097,
        "pitch": 0.13260167361399056,
        "fov": 1.4185322104917357
      },
      "linkHotspots": [
        {
          "yaw": -0.1758018324116115,
          "pitch": 0.04628112754476987,
          "rotation": 0,
          "target": "0-20210301_234416_900"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-20210301_234421_150",
      "name": "20210301_234421_150",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.200020400738671,
        "pitch": 0.2538830900580322,
        "fov": 1.4185322104917357
      },
      "linkHotspots": [
        {
          "yaw": -0.2653351585756454,
          "pitch": 0.08013494700423962,
          "rotation": 0,
          "target": "0-20210301_234416_900"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
